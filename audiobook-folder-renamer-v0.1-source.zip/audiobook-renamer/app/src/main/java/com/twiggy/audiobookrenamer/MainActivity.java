package com.twiggy.audiobookrenamer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.graphics.Color;
import android.view.View;
import android.widget.*;
import java.util.*;
import java.util.regex.*;

public class MainActivity extends Activity {
    private static final int PICK_FOLDER = 41;
    private final ArrayList<Entry> entries = new ArrayList<>();
    private LinearLayout results;
    private TextView status;
    private Uri rootUri;
    private int scanned;
    private static class Entry {
        Uri uri;
        String original, proposed, parent;
        boolean selected;
        Entry(Uri u, String o, String p, String parent) { uri=u; original=o; proposed=p; this.parent=parent; selected=!o.equals(p); }
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout page=new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(20,22,20,16); page.setBackgroundColor(Color.rgb(24,26,32));
        TextView title=text("Audiobook Folder Renamer",23); page.addView(title);
        TextView sub=text("v0.1 • Local-only • Preview before rename",13); page.addView(sub);
        Button pick=button("Select audiobook folder"); page.addView(pick);
        pick.setOnClickListener(v->{ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION); startActivityForResult(i,PICK_FOLDER); });
        status=text("Choose your Author, Series, or audiobook collection folder. The app only proposes changes to book folders.",14); page.addView(status);
        Button apply=button("Rename checked folders"); page.addView(apply);
        apply.setOnClickListener(v->confirmRename());
        ScrollView scroll=new ScrollView(this); results=new LinearLayout(this); results.setOrientation(LinearLayout.VERTICAL); scroll.addView(results);
        page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(page);
    }
    private TextView text(String s,int size) { TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size); t.setPadding(4,12,4,12); return t; }
    private Button button(String s){ Button b=new Button(this); b.setText(s); return b; }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request!=PICK_FOLDER||result!=RESULT_OK||data==null) return;
        rootUri=data.getData(); if(rootUri==null)return;
        try {getContentResolver().takePersistableUriPermission(rootUri,Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);}catch(Exception ignored){}
        scan();
    }
    private static class Child { Uri uri; String name; boolean directory; Child(Uri u,String n,boolean d){uri=u;name=n;directory=d;} }
    private ArrayList<Child> children(Uri parent){
        ArrayList<Child> out=new ArrayList<>();
        String id=DocumentsContract.getDocumentId(parent);
        Uri query=DocumentsContract.buildChildDocumentsUriUsingTree(rootUri,id);
        try(android.database.Cursor c=getContentResolver().query(query,new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE},null,null,null)){
            if(c!=null)while(c.moveToNext()){
                String doc=c.getString(0),name=c.getString(1),type=c.getString(2);
                out.add(new Child(DocumentsContract.buildDocumentUriUsingTree(rootUri,doc),name,DocumentsContract.Document.MIME_TYPE_DIR.equals(type)));
            }
        }catch(Exception e){ status.setText("Cannot read some folders: "+e.getMessage()); }
        return out;
    }
    private void scan(){
        entries.clear(); scanned=0;
        try { walk(rootUri,0,""); }catch(Exception e){status.setText("Scan error: "+e.getMessage());}
        status.setText("Found "+entries.size()+" book folders. Tap a proposed name to edit it. Nothing changes until you confirm.");
        render();
    }
    private void walk(Uri uri,int depth,String parent){
        if(depth>5||scanned++>4000)return;
        ArrayList<Child> kids=children(uri);
        boolean audio=false, hasDir=false;
        for(Child c:kids){ if(c.directory)hasDir=true; else if(c.name.matches("(?i).*\\.(mp3|m4b|m4a|flac|ogg|opus|aac|wma|wav)$"))audio=true; }
        // A book is a folder containing audio files; never rename author/series folders.
        if(audio){
            String name=getName(uri);
            String suggestion=suggest(name,parent);
            entries.add(new Entry(uri,name,suggestion,parent));
            return;
        }
        for(Child c:kids)if(c.directory)walk(c.uri,depth+1,getName(uri));
    }
    private String getName(Uri uri){
        try(android.database.Cursor c=getContentResolver().query(uri,new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME},null,null,null)){
            if(c!=null&&c.moveToFirst())return c.getString(0);
        }catch(Exception ignored){}
        return "Unknown";
    }
    private String suggest(String name,String parent){
        String n=name.trim().replace('_',' ').replaceAll("\\s+"," ");
        // Conservative: only rewrite when book number is explicit. No guessed titles.
        Matcher m=Pattern.compile("(?i)^(.*?)\\s*(?:book|vol(?:ume)?\\.?|#)\\s*0*(\\d+(?:\\.\\d+)?)\\s*[-:–]?\\s*(.+)$").matcher(n);
        if(m.matches()){
            String series=m.group(1).trim().replaceAll("[-:–]$","").trim();
            if(series.isEmpty())series=parent;
            return series+" "+normalizeNumber(m.group(2))+" - "+m.group(3).trim();
        }
        Matcher already=Pattern.compile("^(.*?)\\s+0*(\\d+(?:\\.\\d+)?)\\s*[-–:]\\s*(.+)$").matcher(n);
        if(already.matches())return already.group(1).trim()+" "+normalizeNumber(already.group(2))+" - "+already.group(3).trim();
        return name; // Unknown book number: leave untouched.
    }
    private String normalizeNumber(String n){try {return new java.math.BigDecimal(n).stripTrailingZeros().toPlainString();}catch(Exception e){return n;}}
    private void render(){
        results.removeAllViews();
        if(entries.isEmpty()){results.addView(text("No book folders found. Select a folder containing audiobook subfolders.",14));return;}
        for(Entry e:entries){
            LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(8,8,8,18);
            CheckBox check=new CheckBox(this);check.setText(e.original);check.setTextColor(Color.WHITE);check.setChecked(e.selected);
            check.setOnCheckedChangeListener((b,v)->e.selected=v);box.addView(check);
            TextView proposed=text("→ "+e.proposed+"  ✎",14); proposed.setTextColor(Color.rgb(157,219,175));box.addView(proposed);
            proposed.setOnClickListener(v->{EditText input=new EditText(this);input.setSingleLine(true);input.setText(e.proposed);
                new AlertDialog.Builder(this).setTitle("Edit proposed folder name").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{
                    String next=input.getText().toString().trim();if(valid(next)){e.proposed=next;e.selected=!next.equals(e.original);render();}else toast("Invalid folder name");
                }).show();});
            results.addView(box);
            View line=new View(this);line.setBackgroundColor(Color.DKGRAY);results.addView(line,new LinearLayout.LayoutParams(-1,1));
        }
    }
    private boolean valid(String n){return !n.isEmpty()&&!n.equals(".")&&!n.equals("..")&&!n.contains("/")&&!n.contains("\\")&&!n.contains("\u0000");}
    private void confirmRename(){
        ArrayList<Entry> chosen=new ArrayList<>();for(Entry e:entries)if(e.selected&&!e.original.equals(e.proposed))chosen.add(e);
        if(chosen.isEmpty()){toast("No changes selected");return;}
        new AlertDialog.Builder(this).setTitle("Rename "+chosen.size()+" folders?")
            .setMessage("Only selected book folder names will change. Audio files are not modified. Back up your collection before bulk changes.")
            .setNegativeButton("Cancel",null).setPositiveButton("Rename",(d,w)->rename(chosen)).show();
    }
    private void rename(ArrayList<Entry> chosen){
        int ok=0;StringBuilder errors=new StringBuilder();
        for(Entry e:chosen){
            if(!valid(e.proposed)){errors.append("Invalid: ").append(e.original).append("\n");continue;}
            try {
                Uri renamed=DocumentsContract.renameDocument(getContentResolver(),e.uri,e.proposed);
                if(renamed==null)throw new Exception("Provider refused rename");
                e.uri=renamed;e.original=e.proposed;e.selected=false;ok++;
            }catch(Exception ex){errors.append(e.original).append(": ").append(ex.getMessage()).append("\n");}
        }
        render();
        new AlertDialog.Builder(this).setTitle("Finished: "+ok+" renamed")
            .setMessage(errors.length()==0?"Folder names updated successfully.":errors.toString())
            .setPositiveButton("OK",null).show();
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
