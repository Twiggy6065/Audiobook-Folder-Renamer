# Audiobook Folder Renamer — Android v0.1

A **local-only early prototype** for Samsung/Android tablets. It renames book *folders*, not audio files.

## What works
- Android folder picker (Storage Access Framework); no all-files permission required.
- Scan up to six levels deep, identifying book folders by audio files inside.
- Conservative cleanup of explicit series/book numbers (`01` → `1`).
- Preview and manually edit proposed folder names.
- Checkboxes and a confirmation dialog before renaming.

## Limitations
- **Online official book-title lookup is not implemented yet.** Ambiguous folders are left unchanged for manual editing.
- No undo history or guaranteed collision prevention yet. **Back up your collection and test on a small sample folder.**
- Folder providers differ: some may not permit renaming. Large libraries can make scanning slow.
- Debug APK is not signed for distribution through the Play Store.

## Build on GitHub
1. Upload the project files and folders into the **root** of your GitHub repository, preserving paths (including `.github/workflows/android.yml`).
2. Open **Actions** → **Build Android APK** → latest successful run.
3. Under **Artifacts**, download `audiobook-folder-renamer-v0.1-debug`.
4. Extract the ZIP, then install `app-debug.apk` on your Android tablet.

GitHub Actions will also build when changes are pushed to `main`.

## Folder format
`Author / Series / Series 1 - Book Title / audio files`

Standalone books can keep their existing title folder. Leading zeros are removed when a book number can be identified safely.
